#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════
#  apply-zulu-patch.sh
#  Run this from the root of openclaw-android-main/
#  It renames, patches, and inserts all Zulu modifications.
# ═══════════════════════════════════════════════════════════
set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
OC_ROOT="$(pwd)"

echo "⬡ Applying Zulu patch to: $OC_ROOT"

# 1. Copy modified source files
cp "$SCRIPT_DIR/android/app/src/main/res/values/strings.xml"  "$OC_ROOT/android/app/src/main/res/values/strings.xml"
cp "$SCRIPT_DIR/android/app/src/main/res/values/colors.xml"   "$OC_ROOT/android/app/src/main/res/values/colors.xml"
cp "$SCRIPT_DIR/android/app/src/main/AndroidManifest.xml"     "$OC_ROOT/android/app/src/main/AndroidManifest.xml"
cp "$SCRIPT_DIR/android/app/build.gradle.kts"                 "$OC_ROOT/android/app/build.gradle.kts"
cp "$SCRIPT_DIR/android/www/src/styles/global.css"            "$OC_ROOT/android/www/src/styles/global.css"
cp "$SCRIPT_DIR/android/www/src/screens/Dashboard.tsx"        "$OC_ROOT/android/www/src/screens/Dashboard.tsx"
cp "$SCRIPT_DIR/android/www/src/screens/Settings.tsx"         "$OC_ROOT/android/www/src/screens/Settings.tsx"
cp "$SCRIPT_DIR/android/www/src/screens/Setup.tsx"            "$OC_ROOT/android/www/src/screens/Setup.tsx"
cp "$SCRIPT_DIR/android/www/src/App.tsx"                      "$OC_ROOT/android/www/src/App.tsx"
cp "$SCRIPT_DIR/android/app/src/main/assets/www/zulu.svg"     "$OC_ROOT/android/app/src/main/assets/www/zulu.svg"

# 2. Add ZuluService.kt alongside the existing Kotlin sources
JAVA_DIR="$OC_ROOT/android/app/src/main/java"
ZULU_PKG="$JAVA_DIR/com/zulu/android"
OC_PKG="$JAVA_DIR/com/openclaw/android"
mkdir -p "$ZULU_PKG"
cp "$SCRIPT_DIR/android/app/src/main/java/com/zulu/android/ZuluService.kt" "$ZULU_PKG/ZuluService.kt"

# 3. Rename package references in MainActivity.kt (keep original, add alias)
sed -i 's/com\.openclaw\.android/com.zulu.android/g' "$OC_PKG/MainActivity.kt"
sed -i 's/OpenClawService/ZuluService/g'               "$OC_PKG/MainActivity.kt"
sed -i 's/getSharedPreferences("openclaw"/getSharedPreferences("zulu"/g' "$OC_PKG/MainActivity.kt"

# 4. Rename package in all Kotlin files
for f in "$OC_PKG"/*.kt; do
  sed -i 's/^package com\.openclaw\.android/package com.zulu.android/' "$f"
done

# 5. Update settings.gradle namespace
sed -i 's/com\.openclaw\.android/com.zulu.android/g' "$OC_ROOT/android/settings.gradle.kts" 2>/dev/null || true

# 6. Patch www/index.html to load Orbitron + JetBrains Mono
INDEX="$OC_ROOT/android/app/src/main/assets/www/index.html"
if ! grep -q "Orbitron" "$INDEX"; then
  sed -i 's|</head>|<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900\&family=JetBrains+Mono:wght@300;400;500;700\&display=swap"></head>|' "$INDEX"
fi

# 7. Replace openclaw command alias with zulu in shell environment
OC_ENV="$OC_ROOT/platforms/openclaw/env.sh"
if [ -f "$OC_ENV" ]; then
  echo "" >> "$OC_ENV"
  echo "# Zulu alias — maps zulu -> openclaw so Openclaw engine runs unchanged" >> "$OC_ENV"
  echo "alias zulu='openclaw'" >> "$OC_ENV"
fi

echo ""
echo "✓ Zulu patch applied."
echo ""
echo "Next steps:"
echo "  1. cd android"
echo "  2. ./gradlew assembleRelease"
echo "  3. Rename output APK to zulu.apk"
