# ZULU — Built on Openclaw Android

> Zulu is a cyber-themed AI agent APK, evolved from the Openclaw framework.
> All original APIs, server connections, and Openclaw core logic are preserved intact.

---

## What Changed (Openclaw → Zulu)

### Branding
| File | Change |
|------|--------|
| `res/values/strings.xml` | `app_name` → **"Zulu"**; notification labels renamed |
| `res/values/colors.xml` | Full cyber palette: black void + **neon green `#00FF88`** |
| `android/app/build.gradle.kts` | `applicationId` → `com.zulu.android`; `versionName` → `1.0.0-zulu` |
| `AndroidManifest.xml` | Service renamed to `ZuluService`; extended permissions added |
| `ZuluService.kt` | Renamed from `OpenClawService.kt`; logic identical |
| `zulu.svg` | New hexagonal Z logo (neon green glyph) |

### UI / Theme
| File | Change |
|------|--------|
| `styles/global.css` | **Complete rewrite** — cyber/hacker aesthetic |
| | Fonts: **Orbitron** (display) + **JetBrains Mono** (body/code) |
| | Scanline background overlay on `body` |
| | Glassmorphism cards with neon border glow |
| | Neon green accent throughout; error red `#FF3B5C` |
| `App.tsx` | Tab bar redesigned: icon glyphs + UPPERCASE labels + glow indicator |

### Dashboard (`Dashboard.tsx`) — **Major additions**
- **Uptime counter** — live HH:MM:SS display
- **4-stat grid** — Agents / Requests / Node.js / Zulu version
- **Mini line graph** — live network activity (Canvas, auto-updates)
- **Leaflet map** — free OpenStreetMap tiles, no API key; neon markers on each traced IP
- **Live request feed** — last 5 requests: status code, method, host, IP
- **Agent ecosystem panel** — shows each agent with progress bar; "+ Deploy Agent" button
- All original commands (`gateway`, `status`, `onboard`, `logs`, `oa --update`) **preserved**

### Settings (`Settings.tsx`) — **Admin gate added**
- Admin password: **`@Goodhope07`**
- Items route to existing sub-screens unchanged
- **Admin Panel** (password-gated) adds: theme selector, user profile, sound, agent kill/restart

### Setup (`Setup.tsx`)
- Cyber-styled onboarding: hex logo, Orbitron type, progress bar with tips
- Platform renamed to "Zulu / Openclaw" — original platform ID `openclaw` preserved

---

## Permissions Added (`AndroidManifest.xml`)
```
READ_EXTERNAL_STORAGE
WRITE_EXTERNAL_STORAGE
MANAGE_EXTERNAL_STORAGE
ACCESS_NETWORK_STATE
ACCESS_WIFI_STATE
CHANGE_NETWORK_STATE
FOREGROUND_SERVICE_DATA_SYNC
POST_NOTIFICATIONS
```
All original permissions retained.

---

## What Was NOT Changed (Openclaw core preserved)
- `JsBridge.kt` — all JavaScript bridge methods intact
- `BootstrapManager.kt` — bootstrap/install logic unchanged
- `TerminalSessionManager.kt` — PTY session management unchanged
- `CommandRunner.kt`, `EnvironmentBuilder.kt`, `EventBridge.kt` — unchanged
- `BootReceiver.kt` — unchanged
- `MainActivity.kt` — unchanged (references `ZuluService` instead of `OpenClawService`)
- All shell scripts (`post-setup.sh`, `install.sh`, `oa.sh`, etc.) — unchanged
- All platform configs (`platforms/openclaw/`) — unchanged
- Bootstrap URLs — original Openclaw/Termux URLs preserved
- `terminal-emulator` / `terminal-view` modules — unchanged

---

## Map Integration
Uses **Leaflet.js + OpenStreetMap** — free, no API key, no paid plan.
Loaded via CDN in `Dashboard.tsx`. Tiles are filtered dark with CSS:
```css
.leaflet-tile { filter: brightness(0.35) hue-rotate(100deg) saturate(2); }
```

---

## Build
```bash
cd android
./gradlew assembleRelease
```
Output: `android/app/build/outputs/apk/release/app-release.apk`

Rename to `zulu.apk` for distribution.
