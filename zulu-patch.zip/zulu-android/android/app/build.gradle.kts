import java.util.Properties

plugins {
    alias(libs.plugins.androidApplication)
    alias(libs.plugins.detekt)
    alias(libs.plugins.ktlint)
}

android {
    namespace = "com.zulu.android"
    compileSdk = 36

    dependenciesInfo {
        includeInApk = false
        includeInBundle = false
    }

    defaultConfig {
        applicationId = "com.zulu.android"
        minSdk = 24
        //noinspection ExpiredTargetSdkVersion
        targetSdk = 28
        versionCode = 1
        versionName = "1.0.0-zulu"

        ndk { abiFilters += listOf("arm64-v8a") }

        // Bootstrap URLs — original Openclaw infrastructure preserved
        buildConfigField(
            "String",
            "BOOTSTRAP_URL",
            "\"https://github.com/termux/termux-packages/releases/download/bootstrap-2026.02.12-r1%2Bapt.android-7/bootstrap-aarch64.zip\"",
        )
        buildConfigField(
            "String",
            "WWW_URL",
            "\"https://github.com/AidanPark/openclaw-android-app/releases/download/v1.0.0/www.zip\"",
        )
        buildConfigField(
            "String",
            "CONFIG_URL",
            "\"https://raw.githubusercontent.com/AidanPark/openclaw-android-app/main/config.json\"",
        )
        buildConfigField("String", "APP_NAME", "\"Zulu\"")
        buildConfigField("String", "APP_ID",   "\"zulu\"")
    }

    signingConfigs {
        create("release") {
            val props = project.rootProject.file("local.properties")
            if (props.exists()) {
                val localProps = Properties().apply { props.inputStream().use { load(it) } }
                val storePath = localProps.getProperty("RELEASE_STORE_FILE", "")
                if (storePath.isNotEmpty()) {
                    storeFile = file(storePath)
                    storePassword = localProps.getProperty("RELEASE_STORE_PASSWORD", "")
                    keyAlias      = localProps.getProperty("RELEASE_KEY_ALIAS", "")
                    keyPassword   = localProps.getProperty("RELEASE_KEY_PASSWORD", "")
                }
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro",
            )
            signingConfig = signingConfigs.getByName("release")
        }
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix   = "-debug"
        }
    }

    buildFeatures {
        viewBinding  = true
        buildConfig  = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions { jvmTarget = "17" }

    packaging {
        resources { excludes += setOf("META-INF/LICENSE*", "META-INF/NOTICE*") }
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.gson)
    implementation(libs.kotlinx.coroutines.android)
    implementation(project(":terminal-emulator"))
    implementation(project(":terminal-view"))

    testImplementation(libs.junit)
    testImplementation(libs.mockk)
}
