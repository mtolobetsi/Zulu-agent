import { useState } from 'react'
import { useRoute } from '../lib/router'
import { t } from '../i18n'
import { bridge } from '../lib/bridge'

const ADMIN_PASSWORD = '@Goodhope07'

interface SettingsItem {
  label: string
  desc: string
  path: string
  adminOnly?: boolean
  icon: string
}

function getItems(): SettingsItem[] {
  return [
    { label: 'Keep Alive',   desc: t('settings_keep_alive_desc'),   path: '/settings/keep-alive',  icon: '⬡' },
    { label: 'Storage',      desc: t('settings_storage_desc'),       path: '/settings/storage',     icon: '◈' },
    { label: 'Platforms',    desc: t('settings_platforms_desc'),     path: '/settings/platforms',   icon: '◉' },
    { label: 'Tools',        desc: t('settings_tools_desc'),         path: '/settings/tools',       icon: '◧' },
    { label: 'Updates',      desc: t('settings_updates_desc'),       path: '/settings/updates',     icon: '↺'  },
    { label: 'Admin Panel',  desc: 'Restricted — admin access only', path: '/settings/admin',       icon: '⬒', adminOnly: true },
    { label: 'About Zulu',   desc: t('settings_about_desc'),         path: '/settings/about',       icon: '◌' },
  ]
}

// ── Admin gate modal ──────────────────────────────────────────────────────────
function AdminModal({ onSuccess, onClose }: { onSuccess: () => void; onClose: () => void }) {
  const [pw, setPw] = useState('')
  const [err, setErr] = useState(false)
  const [shake, setShake] = useState(false)

  function attempt() {
    if (pw === ADMIN_PASSWORD) {
      onSuccess()
    } else {
      setErr(true)
      setShake(true)
      setTimeout(() => setShake(false), 500)
      setPw('')
    }
  }

  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 999,
      background: 'rgba(0,0,0,0.85)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      backdropFilter: 'blur(8px)',
    }}>
      <div style={{
        background: 'rgba(6, 18, 10, 0.96)',
        border: '1px solid var(--border-bright)',
        borderRadius: 12,
        padding: '32px 28px',
        width: 300,
        boxShadow: 'var(--glow-md)',
        transform: shake ? 'translateX(-6px)' : 'none',
        transition: 'transform 0.1s',
      }}>
        <div style={{
          fontFamily: 'Orbitron, monospace', fontSize: 11,
          letterSpacing: '0.2em', textTransform: 'uppercase',
          color: 'var(--warning)', marginBottom: 6,
        }}>⚠ ADMIN ACCESS</div>
        <div style={{ fontSize: 12, color: 'var(--text-secondary)', marginBottom: 24, lineHeight: 1.5 }}>
          This section requires the administrator password.
        </div>
        <input
          type="password"
          value={pw}
          onChange={e => { setPw(e.target.value); setErr(false) }}
          onKeyDown={e => e.key === 'Enter' && attempt()}
          placeholder="Enter admin password"
          autoFocus
          style={{
            width: '100%',
            background: 'rgba(0,0,0,0.5)',
            border: `1px solid ${err ? 'var(--error)' : 'var(--border)'}`,
            borderRadius: 6,
            padding: '10px 14px',
            color: 'var(--neon)',
            fontFamily: 'JetBrains Mono, monospace',
            fontSize: 13,
            outline: 'none',
            caretColor: 'var(--neon)',
            marginBottom: err ? 8 : 20,
          }}
        />
        {err && (
          <div style={{ fontSize: 11, color: 'var(--error)', marginBottom: 14, fontFamily: 'JetBrains Mono, monospace' }}>
            ACCESS DENIED
          </div>
        )}
        <div style={{ display: 'flex', gap: 10 }}>
          <button className="btn btn-full" style={{ flex: 1 }} onClick={onClose}>Cancel</button>
          <button className="btn btn-primary btn-full" style={{ flex: 1 }} onClick={attempt}>Unlock</button>
        </div>
      </div>
    </div>
  )
}

// ── Admin Panel (shown after password) ───────────────────────────────────────
function AdminPanel() {
  const [theme, setTheme] = useState<'cyber' | 'dim' | 'ultra'>('cyber')
  const [sound, setSound] = useState(false)
  const [profile, setProfile] = useState('root')

  return (
    <div className="page">
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 24 }}>
        <div className="zulu-wordmark" style={{ fontSize: 18 }}>ADMIN</div>
        <div className="admin-badge">🔓 AUTHENTICATED</div>
      </div>

      <div className="section-title">Appearance</div>
      <div className="card">
        {(['cyber', 'dim', 'ultra'] as const).map((m, i) => (
          <div key={m} className="card-row" style={{ borderTop: i > 0 ? '1px solid var(--border)' : 'none' }}
            onClick={() => setTheme(m)}>
            <div className="card-content">
              <div className="card-label" style={{ textTransform: 'capitalize' }}>{m === 'cyber' ? 'Cyber (Default)' : m === 'dim' ? 'Dim Mode' : 'Ultra Bright'}</div>
            </div>
            {theme === m && <span style={{ color: 'var(--neon)', fontSize: 16 }}>✓</span>}
          </div>
        ))}
      </div>

      <div className="section-title">User Profile</div>
      <div className="card">
        {['root', 'operator', 'observer'].map((p, i) => (
          <div key={p} className="card-row" style={{ borderTop: i > 0 ? '1px solid var(--border)' : 'none' }}
            onClick={() => setProfile(p)}>
            <div className="card-content">
              <div className="card-label" style={{ textTransform: 'capitalize' }}>{p}</div>
            </div>
            {profile === p && <span style={{ color: 'var(--neon)', fontSize: 16 }}>✓</span>}
          </div>
        ))}
      </div>

      <div className="section-title">Sound</div>
      <div className="card">
        <div className="card-row">
          <div className="card-content"><div className="card-label">Alert Sounds</div></div>
          <div className={`toggle ${sound ? 'on' : ''}`} onClick={() => setSound(s => !s)} />
        </div>
      </div>

      <div className="section-title">Agent Management</div>
      <div className="card">
        <div className="card-row" onClick={() => bridge.call('showTerminal')}>
          <div className="card-content">
            <div className="card-label">Kill All Agents</div>
            <div className="card-desc">Terminate all running Zulu sessions</div>
          </div>
          <div className="card-chevron" style={{ color: 'var(--error)' }}>›</div>
        </div>
        <div className="card-row" style={{ borderTop: '1px solid var(--border)' }}
          onClick={() => bridge.call('writeToTerminal', '', 'zulu gateway')}>
          <div className="card-content">
            <div className="card-label">Restart Gateway</div>
            <div className="card-desc">zulu gateway</div>
          </div>
          <div className="card-chevron">›</div>
        </div>
      </div>

      <div style={{ height: 32 }} />
    </div>
  )
}

// ── Main Settings list ────────────────────────────────────────────────────────
export function Settings() {
  const { navigate } = useRoute()
  const [showAdminModal, setShowAdminModal] = useState(false)
  const [adminUnlocked, setAdminUnlocked]   = useState(false)
  const [adminOpen, setAdminOpen]           = useState(false)

  if (adminOpen) return <AdminPanel />

  function handleItem(item: SettingsItem) {
    if (item.adminOnly) {
      if (adminUnlocked) {
        setAdminOpen(true)
      } else {
        setShowAdminModal(true)
      }
      return
    }
    navigate(item.path)
  }

  const items = getItems()

  return (
    <div className="page">
      {showAdminModal && (
        <AdminModal
          onSuccess={() => { setAdminUnlocked(true); setShowAdminModal(false); setAdminOpen(true) }}
          onClose={() => setShowAdminModal(false)}
        />
      )}

      <div style={{ marginBottom: 24 }}>
        <div className="zulu-wordmark" style={{ fontSize: 22 }}>SETTINGS</div>
        <div style={{ fontSize: 11, color: 'var(--text-dim)', marginTop: 4, fontFamily: 'JetBrains Mono, monospace' }}>
          // system configuration
        </div>
      </div>

      <div className="card">
        {items.map((item, i) => (
          <div
            key={item.path}
            className="card-row"
            style={{ borderTop: i > 0 ? '1px solid var(--border)' : 'none', cursor: 'pointer' }}
            onClick={() => handleItem(item)}
          >
            <div style={{
              width: 32, height: 32,
              borderRadius: 8,
              background: 'var(--neon-trace)',
              border: '1px solid var(--border)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 16, flexShrink: 0,
              color: item.adminOnly ? 'var(--warning)' : 'var(--neon)',
            }}>{item.icon}</div>
            <div className="card-content">
              <div className="card-label">{item.label}
                {item.adminOnly && !adminUnlocked && (
                  <span style={{ marginLeft: 8, fontSize: 9, color: 'var(--warning)',
                    fontFamily: 'Orbitron, monospace', letterSpacing: '0.1em' }}>
                    LOCKED
                  </span>
                )}
              </div>
              <div className="card-desc">{item.desc}</div>
            </div>
            <div className="card-chevron">›</div>
          </div>
        ))}
      </div>

      <div style={{ height: 32 }} />
    </div>
  )
}
