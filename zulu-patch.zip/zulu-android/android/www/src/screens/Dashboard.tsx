import { useState, useEffect, useRef, useCallback } from 'react'
import { bridge } from '../lib/bridge'
import { t } from '../i18n'

interface BootstrapStatus {
  installed: boolean
  prefixPath?: string
}

interface PlatformInfo {
  id: string
  name: string
}

interface NetworkRequest {
  id: number
  ip: string
  host: string
  lat: number
  lng: number
  method: string
  status: number
  ts: number
}

interface AgentStatus {
  id: string
  name: string
  active: boolean
  task: string
  progress: number
}

// --- Commands preserved from Openclaw, re-labelled Zulu ---
function getCommands() {
  return [
    { label: 'Gateway', cmd: 'zulu gateway',         desc: t('cmd_gateway') },
    { label: 'Status',  cmd: 'zulu status',           desc: t('cmd_status') },
    { label: 'Onboard', cmd: 'zulu onboard',          desc: t('cmd_onboard') },
    { label: 'Logs',    cmd: 'zulu logs --follow',    desc: t('cmd_logs') },
  ]
}
function getManagement() {
  return [
    { label: 'Update',        cmd: 'oa --update',   desc: t('cmd_update') },
    { label: 'Install Tools', cmd: 'oa --install',  desc: t('cmd_install_tools') },
  ]
}

// Simulated live network requests (replace with real bridge calls when available)
function mockRequest(id: number): NetworkRequest {
  const hosts = [
    { host: 'api.anthropic.com', ip: '104.21.48.1',  lat: 37.77, lng: -122.41 },
    { host: 'github.com',        ip: '140.82.113.4', lat: 37.38, lng: -121.88 },
    { host: 'registry.npmjs.org',ip: '104.16.20.35', lat: 40.71, lng: -74.00  },
    { host: 'pypi.org',          ip: '151.101.0.63', lat: 51.51, lng: -0.12   },
    { host: 'cdn.termux.dev',    ip: '172.67.70.15', lat: 48.86, lng: 2.35    },
  ]
  const h = hosts[id % hosts.length]
  return {
    id,
    ip: h.ip,
    host: h.host,
    lat: h.lat,
    lng: h.lng,
    method: ['GET','POST','GET','GET'][id % 4],
    status: id % 7 === 0 ? 404 : 200,
    ts: Date.now(),
  }
}

// ── Mini Line Graph ────────────────────────────────────────────────────────────
function MiniGraph({ data, label }: { data: number[]; label: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas || data.length < 2) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return
    const W = canvas.width = canvas.offsetWidth * window.devicePixelRatio
    const H = canvas.height = canvas.offsetHeight * window.devicePixelRatio
    ctx.clearRect(0, 0, W, H)

    const max = Math.max(...data, 1)
    const step = W / (data.length - 1)

    // Fill gradient
    const grad = ctx.createLinearGradient(0, 0, 0, H)
    grad.addColorStop(0, 'rgba(0,255,136,0.25)')
    grad.addColorStop(1, 'rgba(0,255,136,0)')

    ctx.beginPath()
    data.forEach((v, i) => {
      const x = i * step
      const y = H - (v / max) * H * 0.85 - H * 0.05
      i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y)
    })
    const lastX = (data.length - 1) * step
    const lastY = H - (data[data.length - 1] / max) * H * 0.85 - H * 0.05
    ctx.lineTo(lastX, H)
    ctx.lineTo(0, H)
    ctx.closePath()
    ctx.fillStyle = grad
    ctx.fill()

    // Line
    ctx.beginPath()
    data.forEach((v, i) => {
      const x = i * step
      const y = H - (v / max) * H * 0.85 - H * 0.05
      i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y)
    })
    ctx.strokeStyle = '#00FF88'
    ctx.lineWidth = 1.5 * window.devicePixelRatio
    ctx.shadowColor = '#00FF88'
    ctx.shadowBlur = 6 * window.devicePixelRatio
    ctx.stroke()
  }, [data])

  return (
    <div style={{ position: 'relative' }}>
      <canvas
        ref={canvasRef}
        className="net-graph"
        style={{ height: 80, width: '100%', display: 'block' }}
      />
      <div style={{
        position: 'absolute', bottom: 6, left: 8,
        fontSize: 9, fontFamily: 'Orbitron, monospace',
        letterSpacing: '0.1em', textTransform: 'uppercase',
        color: 'var(--text-dim)',
      }}>{label}</div>
    </div>
  )
}

// ── Leaflet Map ───────────────────────────────────────────────────────────────
function NetworkMap({ requests }: { requests: NetworkRequest[] }) {
  const mapRef = useRef<HTMLDivElement>(null)
  const leafletMapRef = useRef<any>(null)
  const markersRef = useRef<any[]>([])

  useEffect(() => {
    if (!mapRef.current || leafletMapRef.current) return
    // Dynamically load Leaflet from CDN (free, no API key)
    const link = document.createElement('link')
    link.rel = 'stylesheet'
    link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'
    document.head.appendChild(link)

    const script = document.createElement('script')
    script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'
    script.onload = () => {
      const L = (window as any).L
      const map = L.map(mapRef.current, {
        zoomControl: false,
        attributionControl: false,
        dragging: false,
        scrollWheelZoom: false,
        doubleClickZoom: false,
        center: [20, 10],
        zoom: 1,
      })
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 18,
      }).addTo(map)
      leafletMapRef.current = map
    }
    document.head.appendChild(script)
  }, [])

  useEffect(() => {
    const map = leafletMapRef.current
    if (!map || !(window as any).L) return
    const L = (window as any).L

    // Remove old markers
    markersRef.current.forEach(m => map.removeLayer(m))
    markersRef.current = []

    const icon = L.divIcon({
      className: '',
      html: `<div style="width:10px;height:10px;background:#00FF88;border-radius:50%;
             box-shadow:0 0 8px #00FF88,0 0 16px #00FF88;"></div>`,
      iconSize: [10, 10],
    })

    requests.slice(-8).forEach(r => {
      const m = L.marker([r.lat, r.lng], { icon }).addTo(map)
      m.bindPopup(`<span style="font-family:monospace;font-size:11px;color:#000">${r.host}</span>`)
      markersRef.current.push(m)
    })
  }, [requests])

  return (
    <div style={{ position: 'relative' }}>
      <div ref={mapRef} id="zulu-map" />
      {/* Cyber overlay border */}
      <div style={{
        position: 'absolute', inset: 0, pointerEvents: 'none',
        border: '1px solid var(--border)',
        borderRadius: 'var(--radius-lg)',
        boxShadow: 'inset 0 0 20px rgba(0,255,136,0.05)',
      }} />
      <div style={{
        position: 'absolute', top: 8, left: 10,
        fontFamily: 'Orbitron, monospace', fontSize: 8,
        letterSpacing: '0.15em', textTransform: 'uppercase',
        color: 'var(--neon-dim)', textShadow: '0 0 8px var(--neon)',
        pointerEvents: 'none',
      }}>IP TRACE // LIVE</div>
    </div>
  )
}

// ── Agent card ────────────────────────────────────────────────────────────────
function AgentCard({ agent }: { agent: AgentStatus }) {
  return (
    <div className="card" style={{ marginBottom: 8 }}>
      <div style={{ padding: '10px 0', display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{
          width: 8, height: 8, borderRadius: '50%',
          background: agent.active ? 'var(--neon)' : 'var(--text-dim)',
          boxShadow: agent.active ? 'var(--glow-sm)' : 'none',
          flexShrink: 0,
          animation: agent.active ? 'pulse-badge 1.5s infinite' : 'none',
        }} />
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 12, fontWeight: 500, color: 'var(--text-primary)' }}>{agent.name}</div>
          <div style={{ fontSize: 10, color: 'var(--text-secondary)', marginTop: 2, fontFamily: 'JetBrains Mono, monospace' }}>
            {agent.task}
          </div>
          <div style={{ marginTop: 6 }}>
            <div className="progress-bar">
              <div className="progress-fill" style={{ width: `${agent.progress * 100}%` }} />
            </div>
          </div>
        </div>
        <div style={{ fontFamily: 'Orbitron, monospace', fontSize: 11, color: 'var(--neon)', minWidth: 36, textAlign: 'right' }}>
          {Math.round(agent.progress * 100)}%
        </div>
      </div>
    </div>
  )
}

// ── Dashboard main ────────────────────────────────────────────────────────────
export function Dashboard() {
  const [status, setStatus]         = useState<BootstrapStatus | null>(null)
  const [platform, setPlatform]     = useState<PlatformInfo | null>(null)
  const [runtimeInfo, setRuntimeInfo] = useState<Record<string, string>>({})
  const [netRequests, setNetRequests] = useState<NetworkRequest[]>([])
  const [reqCounter, setReqCounter]   = useState(0)
  const [graphData, setGraphData]     = useState<number[]>(Array(20).fill(0))
  const [agents, setAgents] = useState<AgentStatus[]>([
    { id: 'zulu-1', name: 'Zulu Alpha',  active: true,  task: 'openclaw gateway — monitoring', progress: 0.72 },
    { id: 'zulu-2', name: 'Zulu Beta',   active: false, task: 'idle',                          progress: 0    },
  ])
  const [uptime, setUptime] = useState(0)

  const refreshStatus = useCallback(() => {
    const bs = bridge.callJson<BootstrapStatus>('getBootstrapStatus')
    if (bs) setStatus(bs)
    const ap = bridge.callJson<PlatformInfo>('getActivePlatform')
    if (ap) setPlatform(ap)
    const nodeV = bridge.callJson<{ stdout: string }>('runCommand', 'node -v 2>/dev/null')
    const gitV  = bridge.callJson<{ stdout: string }>('runCommand', 'git --version 2>/dev/null')
    const zuluV = bridge.callJson<{ stdout: string }>('runCommand', 'openclaw --version 2>/dev/null')
    setRuntimeInfo({
      'Node.js': nodeV?.stdout?.trim() || '—',
      'git':     gitV?.stdout?.trim()?.replace('git version ', '') || '—',
      'zulu':    zuluV?.stdout?.trim() || '—',
    })
  }, [])

  useEffect(() => { refreshStatus() }, [refreshStatus])

  // Simulated live network traffic ticker
  useEffect(() => {
    const interval = setInterval(() => {
      setReqCounter(c => {
        const next = c + 1
        const req = mockRequest(next)
        setNetRequests(prev => [...prev.slice(-49), req])
        setGraphData(prev => {
          const updated = [...prev.slice(1), next % 8 + 1 + Math.random() * 4]
          return updated
        })
        return next
      })
    }, 2200)
    return () => clearInterval(interval)
  }, [])

  // Uptime counter
  useEffect(() => {
    const t = setInterval(() => setUptime(u => u + 1), 1000)
    return () => clearInterval(t)
  }, [])

  function formatUptime(secs: number) {
    const h = Math.floor(secs / 3600)
    const m = Math.floor((secs % 3600) / 60)
    const s = secs % 60
    return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`
  }

  function runInTerminal(cmd: string) {
    bridge.call('showTerminal')
    bridge.call('writeToTerminal', '', cmd)
  }

  // Setup not done
  if (!status?.installed) {
    return (
      <div className="page">
        <div className="setup-container" style={{ minHeight: 'calc(100vh - 80px)' }}>
          <div className="zulu-wordmark" style={{ fontSize: 36 }}>ZULU</div>
          <div className="setup-title cursor-blink">AGENT OFFLINE</div>
          <div className="setup-subtitle">Complete system bootstrap to activate Zulu agent network.</div>
        </div>
      </div>
    )
  }

  return (
    <div className="page">

      {/* ── Header ── */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div className="zulu-wordmark" style={{ fontSize: 26 }}>ZULU</div>
          <div className="agent-pill">
            <span className="dot" />
            {platform?.name || 'Agent Active'}
          </div>
        </div>
        <div style={{
          fontFamily: 'JetBrains Mono, monospace',
          fontSize: 13, color: 'var(--neon)',
          textShadow: 'var(--glow-sm)',
        }}>{formatUptime(uptime)}</div>
      </div>

      {/* ── Stat grid ── */}
      <div className="stat-grid">
        <div className="stat-box">
          <div className="stat-label">Agents</div>
          <div className="stat-value">{agents.filter(a => a.active).length}</div>
          <div className="stat-sub">/ {agents.length} total</div>
        </div>
        <div className="stat-box">
          <div className="stat-label">Requests</div>
          <div className="stat-value">{reqCounter}</div>
          <div className="stat-sub">live traced</div>
        </div>
        <div className="stat-box">
          <div className="stat-label">Runtime</div>
          <div className="stat-value" style={{ fontSize: 13, paddingTop: 4 }}>{runtimeInfo['Node.js'] || '—'}</div>
          <div className="stat-sub">node.js</div>
        </div>
        <div className="stat-box">
          <div className="stat-label">Zulu</div>
          <div className="stat-value" style={{ fontSize: 13, paddingTop: 4 }}>{runtimeInfo['zulu'] || 'v0.4'}</div>
          <div className="stat-sub">core version</div>
        </div>
      </div>

      {/* ── Network graph ── */}
      <div className="section-title">Network Activity</div>
      <div className="card" style={{ padding: '12px 16px' }}>
        <MiniGraph data={graphData} label="Req/s" />
      </div>

      {/* ── IP Trace Map ── */}
      <div className="section-title">IP Trace Map</div>
      <NetworkMap requests={netRequests} />

      {/* ── Live requests ── */}
      <div className="section-title">Live Requests</div>
      <div className="card" style={{ padding: 0 }}>
        {netRequests.length === 0 && (
          <div style={{ padding: 16, color: 'var(--text-dim)', fontSize: 12 }}>Waiting for traffic…</div>
        )}
        {netRequests.slice(-5).reverse().map(r => (
          <div key={r.id} style={{
            display: 'flex', alignItems: 'center', gap: 10,
            padding: '8px 16px',
            borderBottom: '1px solid var(--border)',
            fontSize: 11, fontFamily: 'JetBrains Mono, monospace',
          }}>
            <span style={{
              color: r.status === 200 ? 'var(--neon)' : 'var(--error)',
              minWidth: 28, fontWeight: 700,
            }}>{r.status}</span>
            <span style={{ color: 'var(--text-secondary)', minWidth: 34 }}>{r.method}</span>
            <span style={{ color: 'var(--text-primary)', flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r.host}</span>
            <span style={{ color: 'var(--text-dim)' }}>{r.ip}</span>
          </div>
        ))}
      </div>

      {/* ── Agents ── */}
      <div className="section-title">Agent Ecosystem</div>
      {agents.map(a => <AgentCard key={a.id} agent={a} />)}
      <button
        className="btn btn-full"
        style={{ marginTop: 4 }}
        onClick={() => {
          const id = `zulu-${agents.length + 1}`
          setAgents(prev => [...prev, {
            id, name: `Zulu ${String.fromCharCode(67 + prev.length)}`,
            active: false, task: 'idle', progress: 0,
          }])
        }}
      >+ Deploy Agent</button>

      {/* ── Commands ── */}
      <div className="section-title">Commands</div>
      <div className="card">
        {getCommands().map((item, i) => (
          <div
            key={item.cmd}
            className="card-row"
            style={{ borderTop: i > 0 ? '1px solid var(--border)' : 'none' }}
            onClick={() => runInTerminal(item.cmd)}
          >
            <div className="card-content">
              <div className="card-label">{item.label}</div>
              <div className="card-desc">{item.cmd}</div>
            </div>
            <div className="card-chevron">›</div>
          </div>
        ))}
      </div>

      {/* ── Runtime info ── */}
      <div className="section-title">Runtime</div>
      <div className="card">
        {Object.entries(runtimeInfo).map(([key, val]) => (
          <div className="info-row" key={key}>
            <span className="label">{key}</span>
            <span>{val}</span>
          </div>
        ))}
      </div>

      {/* ── Management ── */}
      <div className="section-title">Management</div>
      <div className="card">
        {getManagement().map((item, i) => (
          <div
            key={item.cmd}
            className="card-row"
            style={{ borderTop: i > 0 ? '1px solid var(--border)' : 'none' }}
            onClick={() => runInTerminal(item.cmd)}
          >
            <div className="card-content">
              <div className="card-label">{item.label}</div>
              <div className="card-desc">{item.cmd}</div>
            </div>
            <div className="card-chevron">›</div>
          </div>
        ))}
      </div>

      <div style={{ height: 32 }} />
    </div>
  )
}
