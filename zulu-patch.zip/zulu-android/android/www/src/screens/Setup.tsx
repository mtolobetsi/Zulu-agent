import { useState, useCallback, useEffect, Fragment } from 'react'
import { bridge } from '../lib/bridge'
import { useNativeEvent } from '../lib/useNativeEvent'
import { t } from '../i18n'

interface Props {
  onComplete: () => void
}

type SetupPhase = 'platform-select' | 'tool-select' | 'installing' | 'done'

interface Platform {
  id: string
  name: string
  icon: string
  desc: string
}

function getOptionalTools() {
  return [
    { id: 'tmux',         name: 'tmux',         desc: t('tool_tmux') },
    { id: 'ttyd',         name: 'ttyd',          desc: t('tool_ttyd') },
    { id: 'dufs',         name: 'dufs',          desc: t('tool_dufs') },
    { id: 'code-server',  name: 'code-server',   desc: t('tool_code_server') },
    { id: 'claude-code',  name: 'Claude Code',   desc: t('tool_claude_code') },
    { id: 'gemini-cli',   name: 'Gemini CLI',    desc: t('tool_gemini_cli') },
    { id: 'codex-cli',    name: 'Codex CLI',     desc: t('tool_codex_cli') },
  ]
}

function getTips() {
  return [
    'Zulu uses Openclaw\'s core engine — all APIs preserved.',
    'Agent sessions run headless in background.',
    'Network traffic is traced and mapped in real-time.',
    'Deploy multiple agents from the dashboard.',
  ]
}

export function Setup({ onComplete }: Props) {
  const [phase, setPhase]                 = useState<SetupPhase>('platform-select')
  const [platforms, setPlatforms]         = useState<Platform[]>([])
  const [selectedPlatform, setSelectedPlatform] = useState('')
  const [selectedTools, setSelectedTools] = useState<Set<string>>(new Set())
  const [progress, setProgress]           = useState(0)
  const [message, setMessage]             = useState('')
  const [error, setError]                 = useState('')
  const [tipIndex, setTipIndex]           = useState(0)

  useEffect(() => {
    const data = bridge.callJson<Platform[]>('getAvailablePlatforms')
    if (data) {
      setPlatforms(data)
    } else {
      setPlatforms([
        { id: 'openclaw', name: 'Zulu / Openclaw', icon: '', desc: 'AI agent — full Openclaw engine' },
      ])
    }
  }, [])

  const onProgress = useCallback((data: unknown) => {
    const d = data as { progress?: number; message?: string }
    if (d.progress !== undefined) setProgress(d.progress)
    if (d.message) setMessage(d.message)
    if (d.progress !== undefined && d.progress >= 1) setPhase('done')
    setTipIndex(i => (i + 1) % getTips().length)
  }, [])

  useNativeEvent('setup_progress', onProgress)

  function handleSelectPlatform(id: string) {
    setSelectedPlatform(id)
    setPhase('tool-select')
  }

  function toggleTool(id: string) {
    setSelectedTools(prev => {
      const next = new Set(prev)
      next.has(id) ? next.delete(id) : next.add(id)
      return next
    })
  }

  function startInstall() {
    setPhase('installing')
    setProgress(0)
    setMessage('Initialising Zulu agent environment...')
    bridge.call('startSetup', selectedPlatform, JSON.stringify([...selectedTools]))
  }

  // Phase: platform select
  if (phase === 'platform-select') {
    return (
      <div className="page">
        <div className="setup-container">
          <div className="zulu-wordmark" style={{ fontSize: 42, marginBottom: 4 }}>ZULU</div>
          <div style={{
            fontFamily: 'Orbitron, monospace', fontSize: 9,
            letterSpacing: '0.3em', textTransform: 'uppercase',
            color: 'var(--text-dim)', marginBottom: 32,
          }}>AGENT INITIALISATION</div>

          <div style={{ width: '100%', marginBottom: 16 }}>
            <div className="section-title">Select Platform</div>
            {platforms.map(p => (
              <div
                key={p.id}
                className="card"
                style={{ marginBottom: 10, cursor: 'pointer' }}
                onClick={() => handleSelectPlatform(p.id)}
              >
                <div className="card-row">
                  <div className="card-content">
                    <div className="card-label">{p.name}</div>
                    <div className="card-desc">{p.desc}</div>
                  </div>
                  <div className="card-chevron">›</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  // Phase: tool select
  if (phase === 'tool-select') {
    return (
      <div className="page">
        <div style={{ marginBottom: 20 }}>
          <div className="zulu-wordmark" style={{ fontSize: 20 }}>INSTALL TOOLS</div>
          <div style={{ fontSize: 11, color: 'var(--text-secondary)', marginTop: 4 }}>Optional — select what to install</div>
        </div>
        <div className="card" style={{ marginBottom: 16 }}>
          {getOptionalTools().map((tool, i) => {
            const sel = selectedTools.has(tool.id)
            return (
              <div
                key={tool.id}
                className="card-row"
                style={{ borderTop: i > 0 ? '1px solid var(--border)' : 'none' }}
                onClick={() => toggleTool(tool.id)}
              >
                <div className="card-content">
                  <div className="card-label">{tool.name}</div>
                  <div className="card-desc">{tool.desc}</div>
                </div>
                <div style={{
                  width: 20, height: 20,
                  border: `1px solid ${sel ? 'var(--neon)' : 'var(--border)'}`,
                  borderRadius: 4,
                  background: sel ? 'var(--neon)' : 'transparent',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  color: '#000', fontSize: 13, fontWeight: 700,
                  flexShrink: 0,
                  boxShadow: sel ? 'var(--glow-sm)' : 'none',
                  transition: 'all 0.15s',
                }}>{sel ? '✓' : ''}</div>
              </div>
            )
          })}
        </div>
        <button className="btn btn-primary btn-full" onClick={startInstall}>
          Deploy Zulu
        </button>
        <button className="btn btn-full" style={{ marginTop: 8 }} onClick={startInstall}>
          Skip — minimal install
        </button>
      </div>
    )
  }

  // Phase: installing
  if (phase === 'installing') {
    return (
      <div className="page">
        <div className="setup-container" style={{ minHeight: 'calc(100vh - 80px)' }}>
          <div className="zulu-wordmark" style={{ fontSize: 32 }}>ZULU</div>
          <div style={{
            fontFamily: 'Orbitron, monospace', fontSize: 9,
            letterSpacing: '0.3em', color: 'var(--text-dim)', marginBottom: 32,
          }}>BOOTSTRAP IN PROGRESS</div>

          <div style={{ width: '100%', marginBottom: 20 }}>
            <div className="progress-bar" style={{ height: 4 }}>
              <div className="progress-fill" style={{ width: `${Math.round(progress * 100)}%` }} />
            </div>
            <div style={{
              display: 'flex', justifyContent: 'space-between',
              marginTop: 8, fontSize: 11, color: 'var(--text-secondary)',
              fontFamily: 'JetBrains Mono, monospace',
            }}>
              <span>{message || 'Working...'}</span>
              <span style={{ color: 'var(--neon)' }}>{Math.round(progress * 100)}%</span>
            </div>
          </div>

          {error ? (
            <div style={{
              background: 'rgba(255,59,92,0.08)', border: '1px solid var(--error)',
              borderRadius: 8, padding: '12px 16px', width: '100%',
              fontSize: 12, color: 'var(--error)', fontFamily: 'JetBrains Mono, monospace',
            }}>{error}</div>
          ) : (
            <div style={{
              background: 'var(--neon-trace)', border: '1px solid var(--border)',
              borderRadius: 8, padding: '12px 16px', width: '100%',
              fontSize: 12, color: 'var(--text-secondary)', fontStyle: 'italic',
              fontFamily: 'JetBrains Mono, monospace', lineHeight: 1.6,
            }}>// {getTips()[tipIndex]}</div>
          )}
        </div>
      </div>
    )
  }

  // Phase: done
  return (
    <div className="page">
      <div className="setup-container" style={{ minHeight: 'calc(100vh - 80px)' }}>
        <div className="zulu-wordmark" style={{ fontSize: 42 }}>ZULU</div>
        <div style={{
          fontFamily: 'Orbitron, monospace', fontSize: 12, letterSpacing: '0.2em',
          color: 'var(--neon)', textShadow: 'var(--glow-md)', marginBottom: 8,
        }}>AGENT ONLINE</div>
        <div style={{ fontSize: 13, color: 'var(--text-secondary)', marginBottom: 32 }}>
          System ready. All Openclaw APIs and servers intact.
        </div>
        <button className="btn btn-primary" style={{ minWidth: 200 }} onClick={onComplete}>
          Enter Zulu
        </button>
      </div>
    </div>
  )
}
