import { useState, useEffect, useCallback } from 'react'
import { Route, useRoute } from './lib/router'
import { bridge } from './lib/bridge'
import { useNativeEvent } from './lib/useNativeEvent'
import { t } from './i18n'
import { Setup } from './screens/Setup'
import { Dashboard } from './screens/Dashboard'
import { Settings } from './screens/Settings'
import { SettingsKeepAlive } from './screens/SettingsKeepAlive'
import { SettingsStorage } from './screens/SettingsStorage'
import { SettingsAbout } from './screens/SettingsAbout'
import { SettingsUpdates } from './screens/SettingsUpdates'
import { SettingsPlatforms } from './screens/SettingsPlatforms'
import { SettingsTools } from './screens/SettingsTools'

type Tab = 'terminal' | 'dashboard' | 'settings'

const TAB_ICONS: Record<Tab, string> = {
  terminal:  '▶_',
  dashboard: '◈',
  settings:  '⚙',
}

export function App() {
  const { path, navigate } = useRoute()
  const [hasUpdates, setHasUpdates] = useState(false)
  const [setupDone, setSetupDone]   = useState<boolean | null>(null)

  useEffect(() => {
    const status = bridge.callJson<{ bootstrapInstalled?: boolean; platformInstalled?: string }>(
      'getSetupStatus'
    )
    if (status) {
      setSetupDone(!!status.bootstrapInstalled && !!status.platformInstalled)
    } else {
      setSetupDone(true)
    }
    const updates = bridge.callJson<unknown[]>('checkForUpdates')
    if (updates && updates.length > 0) setHasUpdates(true)
  }, [])

  const onUpdateAvailable = useCallback(() => { setHasUpdates(true) }, [])
  useNativeEvent('update_available', onUpdateAvailable)

  const activeTab: Tab = path.startsWith('/settings') || path.startsWith('/setup')
    ? 'settings'
    : 'dashboard'

  function handleTabClick(tab: Tab) {
    if (tab === 'terminal') {
      bridge.call('showTerminal')
      return
    }
    bridge.call('showWebView')
    if (tab === 'dashboard') navigate('/dashboard')
    if (tab === 'settings')  navigate('/settings')
  }

  if (setupDone === null) return null
  if (!setupDone && !path.startsWith('/setup')) {
    navigate('/setup')
  }

  return (
    <>
      {/* ── Zulu Tab Bar ── */}
      <nav className="tab-bar">
        {(['terminal', 'dashboard', 'settings'] as Tab[]).map(tab => (
          <button
            key={tab}
            className={`tab-bar-item ${activeTab === tab ? 'active' : ''}`}
            onClick={() => handleTabClick(tab)}
          >
            <span style={{ fontSize: tab === 'terminal' ? 11 : 14 }}>{TAB_ICONS[tab]}</span>
            <span>{tab === 'terminal' ? 'SHELL' : tab.toUpperCase()}</span>
            {tab === 'settings' && hasUpdates && <span className="badge" />}
          </button>
        ))}
      </nav>

      {/* ── Routes ── */}
      <Route path="/setup">
        <Setup onComplete={() => { setSetupDone(true); navigate('/dashboard') }} />
      </Route>
      <Route path="/dashboard">
        <Dashboard />
      </Route>
      <Route path="/settings">
        <SettingsRouter />
      </Route>
    </>
  )
}

function SettingsRouter() {
  const { path } = useRoute()
  if (path === '/settings')              return <Settings />
  if (path === '/settings/keep-alive')   return <SettingsKeepAlive />
  if (path === '/settings/storage')      return <SettingsStorage />
  if (path === '/settings/about')        return <SettingsAbout />
  if (path === '/settings/updates')      return <SettingsUpdates />
  if (path === '/settings/platforms')    return <SettingsPlatforms />
  if (path === '/settings/tools')        return <SettingsTools />
  return <Settings />
}
